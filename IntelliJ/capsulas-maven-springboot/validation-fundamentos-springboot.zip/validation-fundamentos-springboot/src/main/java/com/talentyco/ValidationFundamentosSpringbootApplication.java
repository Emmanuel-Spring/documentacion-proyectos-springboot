package com.talentyco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationFundamentosSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationFundamentosSpringbootApplication.class, args);
	}

}
